"""
Topos expected frequency

an alternative to tf-idf to extract topically relevant keywords from text.
"""

__version__ = "0.1"
__author__ = 'Tomás Boncompte'