from setuptools import setup

setup(
    name='topos',
    version='0.1',    
    description='An non tf-idf based algorythm to extract topically relevant keywords',
    url='url',
    author='Tomás Boncompte',
    author_email='tsboncompte@gmail.com',
    license='GNU3',
    packages=['topos'],
    install_requires=['pandas']

)